package com.dockbuddy.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Handler;
import android.view.View;

import org.json.JSONObject;

/** Live input peak meter for the PC's default microphone. */
class MicLevelWidget extends DeckWidget {
    private final Handler handler = new Handler();
    private final MeterView meter;
    private boolean running;
    private boolean requestInFlight;

    MicLevelWidget(DeckHost host) {
        super(host);
        meter = new MeterView(host.context());
    }

    @Override public View view() { return meter; }

    @Override public void onConfigChanged(Deck.Widget config, int cellPx) {
        super.onConfigChanged(config, cellPx);
        meter.setMeterColor(color(0x28C987));
    }

    @Override public void onStart() {
        running = true;
        handler.post(poll);
    }

    @Override public void onStop() {
        running = false;
        requestInFlight = false;
        handler.removeCallbacks(poll);
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (!running) return;
            if (!requestInFlight) {
                requestInFlight = true;
                host.api().get("/api/mic/level", new ApiClient.Callback() {
                    @Override public void onResult(JSONObject j, String error) {
                        requestInFlight = false;
                        if (!running) return;
                        if (j != null) meter.setLevel(j.optInt("level", 0));
                        else meter.setLevel(0);
                    }
                });
            }
            handler.postDelayed(this, 140);
        }
    };

    private static class MeterView extends View {
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float density;
        private int level;
        private float displayed;
        private int meterColor = 0xFF28C987;

        MeterView(Context context) {
            super(context);
            density = context.getResources().getDisplayMetrics().density;
            bg.setColor(0xFF1B2630);
            track.setColor(0xFF35434D);
            label.setColor(0xFFEAF1F4);
            label.setFakeBoldText(true);
            label.setTextAlign(Paint.Align.LEFT);
        }

        void setMeterColor(int color) { meterColor = color; fill.setColor(color); invalidate(); }
        void setLevel(int value) { level = Math.max(0, Math.min(100, value)); invalidate(); }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float pad = 7 * density;
            float radius = 7 * density;
            rect.set(pad, pad, getWidth() - pad, getHeight() - pad);
            canvas.drawRoundRect(rect, radius, radius, bg);

            float left = rect.left + 10 * density;
            float right = rect.right - 10 * density;
            float centerY = rect.centerY();
            float labelSize = Math.min(12 * density, rect.height() * 0.28f);
            label.setTextSize(labelSize);
            canvas.drawText("MIC", left, rect.top + labelSize + 3 * density, label);
            String value = level + "%";
            label.setTextAlign(Paint.Align.RIGHT);
            canvas.drawText(value, right, rect.top + labelSize + 3 * density, label);
            label.setTextAlign(Paint.Align.LEFT);

            float barTop = rect.top + rect.height() * 0.58f;
            float barBottom = rect.bottom - 7 * density;
            rect.set(left, barTop, right, barBottom);
            canvas.drawRoundRect(rect, 4 * density, 4 * density, track);

            // Smooth attack and release so the meter feels responsive without flicker.
            displayed += (level - displayed) * (level > displayed ? 0.72f : 0.24f);
            float fillRight = left + (right - left) * displayed / 100f;
            rect.set(left, barTop, Math.max(left + 2 * density, fillRight), barBottom);
            fill.setColor(level >= 85 ? 0xFFE85D5D : level >= 65 ? 0xFFFFC857 : meterColor);
            canvas.drawRoundRect(rect, 4 * density, 4 * density, fill);
            if (Math.abs(displayed - level) > 1f) postInvalidateDelayed(30);
        }
    }
}
