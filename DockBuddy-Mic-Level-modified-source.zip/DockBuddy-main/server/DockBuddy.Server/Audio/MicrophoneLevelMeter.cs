using System.Runtime.InteropServices;

namespace DockBuddy.Server.Audio;

/// <summary>Reads the live peak level from the default Windows capture endpoint.</summary>
public sealed class WindowsMicrophoneLevelMeter
{
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    private class MMDeviceEnumeratorComObject { }

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator
    {
        int EnumAudioEndpoints(int dataFlow, int stateMask, out IntPtr devices);
        int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice
    {
        int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object iface);
    }

    [ComImport, Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioMeterInformation
    {
        int GetPeakValue(out float peak);
        int GetMeteringChannelCount(out int channelCount);
        int GetChannelsPeakValues(int channelCount, [Out, MarshalAs(UnmanagedType.LPArray, SizeParamIndex = 0)] float[] peaks);
        int QueryHardwareSupport(out int hardwareSupportMask);
    }

    private readonly object _gate = new();
    private IAudioMeterInformation? _meter;
    private DateTime _retryAfter;

    /// <returns>Peak microphone level, normalized to 0..100. Returns zero when unavailable/silent.</returns>
    public int GetLevel()
    {
        if (!OperatingSystem.IsWindows()) return 0;
        lock (_gate)
        {
            try
            {
                if (_meter == null)
                {
                    if (DateTime.UtcNow < _retryAfter) return 0;
                    var enumerator = (IMMDeviceEnumerator)new MMDeviceEnumeratorComObject();
                    Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(1 /* capture */, 1 /* multimedia */, out var device));
                    var iid = typeof(IAudioMeterInformation).GUID;
                    Marshal.ThrowExceptionForHR(device.Activate(ref iid, 23 /* CLSCTX_ALL */, IntPtr.Zero, out var obj));
                    _meter = (IAudioMeterInformation)obj;
                }

                Marshal.ThrowExceptionForHR(_meter.GetPeakValue(out var peak));
                return Math.Clamp((int)Math.Round(peak * 100f), 0, 100);
            }
            catch
            {
                _meter = null;
                _retryAfter = DateTime.UtcNow.AddSeconds(3);
                return 0;
            }
        }
    }
}
